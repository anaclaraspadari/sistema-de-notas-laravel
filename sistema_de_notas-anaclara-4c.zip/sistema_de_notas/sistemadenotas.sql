
create table alunos(
    id_aluno serial primary key,
    nome text not null,
    email text not null,
    matricula int not null
);

create table disciplinas(
    id_disciplina serial primary key,
    cod_disciplina int not null,
    nome text not null,
    carga_horaria int not null
);


create table professores(
    id_professor serial primary key,
    nome text not null,
    email text not null,
    disciplina int not null,
    foreign key (disciplina) references disciplinas(id_disciplina)
);

create table aluno_disciplina(
	aluno int not null,
	disciplina int not null,
	foreign key (aluno) references alunos(id_aluno),
	foreign key (disciplina) references disciplinas(id_disciplina)
);

create table boletim(
    id serial primary key,
    aluno int not null,
    disciplina int not null,
    frequencia numeric(5,2) not null,
    nota numeric(5,2) not null,
    situacao_final text,
    foreign key (aluno) references alunos(id_aluno),
    foreign key (disciplina) references disciplinas(id_disciplina)
);

insert into professores (nome,email, disciplina) values ('Carlos Silveira','professor.carlosilveira@mymail.com',1), ('Camila Costa', 'professor.camilacosta@mymail.com',2), ('Paulo Andrade', 'professor.pauloandrade@mymail.com',3), ('Celso Duarte', 'professor.celsoduarte@mymail.com',4), ('Luciana Sousa', 'professor.lucianasousa@mymail.com',5);

insert into disciplinas (cod_disciplina,nome,carga_horaria) values (110201,'Portugues I',5), (110202,'Matemática I',5), (110203,'Biologia I',5), (110204,'Quimica II',5), (110201,'Fisica III',5);

insert into alunos (nome,email,matricula,situacao) values ('Pedro Silveira','pedrosilveira@mymail.com',01931085,'Regular'), ('Joao Almeida','joaoalmeida@mymail.com',01931086,'Regular'), ('Luana Cardozo','luanacardozo@mymail.com',01973196,'Regular'), ('Rafael Pontes','rafapontes@mymail.com',01931905,'Regular'), ('Laura Brandao','laurabrandao@mymail.com',01931875,'Regular');