<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Notas - Disciplinas</title>
</head>
<body>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <div class="container" style="margin-top: 50px">
        <center><h1 style="color: rgb(87, 87, 87)">Sistema de Notas</h1></center>
    </div>
    <div class="container" style="margin-top: 20px">
        <center><h3 style="color: rgb(87, 87, 87)">Cadastro de Notas</h3></center>
    </div>
    <div id="cadastro-disc">
        <div class="container">
            <div id="cadastro-disc-row" class="row justify-content-center align-items-center">
                <div id="cadastro-disc-column" class="col-md-6">
                    <div id="cadastro-disc-box" class="col-md-12">
                        <form id="cadastro-disc-form" class="form" action="{{ url('/disciplinas-inseridas') }}" method="get">
                            <div class="form-group" style="margin-top: 30px;">
                                <label for="nome_disc" style="color: rgb(87, 87, 87)"><b>Nome da Disciplina:</b></label><br>
                                <input type="text" name="nome_disc" id="nome_disc" class="form-control">
                            </div>
                            <div class="form-group" style="margin-top: 30px;">
                                <label for="carga_horaria_disc" style="color: rgb(87, 87, 87)"><b>Carga Horária:</b></label><br>
                                <input type="text" name="carga_horaria_disc" id="carga_horaria_disc" class="form-control">
                            </div>
                            <div class="form-group">
                                <center><input type="submit" name="submit" class="btn btn-secondary btn-md" style="margin-top: 10px;" value="Cadastrar"></center>
                                <center><a class="btn btn-secondary btn-sm" href="{{ url('/alunos') }}" role="button" style="margin-top: 30px"><i class="fa-solid fa-arrow-left"></i>&nbsp;Voltar</a></center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
    
