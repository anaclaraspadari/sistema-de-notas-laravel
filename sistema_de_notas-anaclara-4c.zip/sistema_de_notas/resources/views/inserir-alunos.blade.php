<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Notas - Cadastro de Alunos</title>
</head>
<body>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/aa4537a345.js" crossorigin="anonymous"></script>

    <div class="container" style="margin-top: 50px">
        <center><h1 style="color: rgb(87, 87, 87)">Sistema de Notas</h1></center>
    </div>
    <div class="container" style="margin-top: 20px">
        <center><h3 style="color: rgb(87, 87, 87)">Cadastro de Alunos</h3></center>
    </div>
    <div id="cadastro">
        <div class="container">
            <div id="cadastro-row" class="row justify-content-center align-items-center">
                <div id="cadastro-column" class="col-md-6">
                    <div id="cadastro-box" class="col-md-12">
                        <form id="cadastro-form" class="form" action="{{ url('alunos-inseridos') }}" method="get">
                            <div class="form-group" style="margin-top: 30px;">
                                <label for="nome_aluno" style="color: rgb(87, 87, 87)"><b>Nome do Aluno:</b></label><br>
                                <input type="text" name="nome_aluno" id="nome_aluno" class="form-control">
                            </div>
                            <div class="form-group" style="margin-top: 30px;">
                                <label for="email_aluno" style="color: rgb(87, 87, 87)"><b>E-mail:</b></label><br>
                                <input type="text" name="email_aluno" id="email_aluno" class="form-control">
                            </div>
                            {{-- <div class="form-group" style="margin-top: 30px;">
                                <label for="sit_aluno" style="color: green">Situação:</label><br>
                                <input type="text" name="sit_aluno" id="sit_aluno" class="form-control">
                            </div> --}}
                            {{-- <div class="form-group" style="margin-top: 30px;">
                                <label for="sit_aluno" style="color: green">Disciplinas:</label><br>
                                @foreach ($disciplinas as $disciplina)
                                    <input type="checkbox" name="{{ $disciplina->cod_disciplina }}" id="{{ $disciplina->cod_disciplina }}"/>
                                    <label>{{ $disciplina->nome }}</label>
                                @endforeach
                            </div> --}}
                            <div class="form-group">
                                <center><input type="submit" name="submit" class="btn btn-secondary btn-md" style="margin-top: 10px;" value="Cadastrar"></center>
                                <center><a class="btn btn-secondary btn-sm" href="{{ url('/alunos') }}" role="button" style="margin-top: 30px"><i class="fa-solid fa-arrow-left"></i>&nbsp;Voltar</a></center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
    
