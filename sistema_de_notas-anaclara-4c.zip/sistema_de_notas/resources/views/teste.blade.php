<strong><p>Conexão com banco: </p></strong>
<?php
    try {
        \DB::connection()->getPDO();
        echo \DB::connection()->getDatabaseName();
    } catch (\Exception $e) {
        print_r($e);
    }
?>