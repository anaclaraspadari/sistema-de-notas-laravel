<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sistema de Notas - Lista de Alunos</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/aa4537a345.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container" style="margin-top: 40px">
        <h3>Lista de Alunos por Professor</h3>
        <h4>Professor: {{ $professor->nome}}</h4>
        <br/>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Nome do Aluno</th>
                    <th scope="col">E-mail</th>
                    <th scope="col">Matrícula</th>
                </tr>
                @foreach($alunos as $aluno)
                    <tr>
                        <td>{{ $aluno->nome_aluno }}</td>
                        <td>{{ $aluno->email_aluno }}</td>
                        <td>{{ $aluno->matricula }}</a></td>
                    </tr>
                @endforeach
            </thead>
        </table>
        <center>
            <a class="btn btn-secondary btn-sm" href="{{ url('/professores') }}" role="button"><i class="fa-solid fa-arrow-left"></i>&nbsp;Voltar</a>
        </center>
    </div>
</body>
</html>

