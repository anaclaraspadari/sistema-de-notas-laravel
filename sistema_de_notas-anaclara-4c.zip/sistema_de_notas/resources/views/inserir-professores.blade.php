<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Notas - Professores</title>
</head>
<body>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <div class="container" style="margin-top: 50px">
        <center><h1 style="color: rgb(87, 87, 87)">Sistema de Notas</h1></center>
    </div>
    <div class="container" style="margin-top: 20px">
        <center><h3 style="color: rgb(87, 87, 87)">Cadastro de Professores</h3></center>
    </div>
    <div id="cadastro-prof">
        <div class="container">
            <div id="cadastro-prof-row" class="row justify-content-center align-items-center">
                <div id="cadastro-prof-column" class="col-md-6">
                    <div id="cadastro-prof-box" class="col-md-12">
                        <form id="cadastro-prof-form" class="form" action="{{ url('/professores-inseridos') }}" method="get">
                            <div class="form-group" style="margin-top: 30px;">
                                <label for="nome_prof" style="color: rgb(87, 87, 87)">Nome do Professor:</label><br>
                                <input type="text" name="nome_prof" id="nome_prof" class="form-control">
                            </div>
                            <div class="form-group" style="margin-top: 30px;">
                                <label for="email_prof" style="color: rgb(87, 87, 87)">E-mail:</label><br>
                                <input type="text" name="email_prof" id="email_prof" class="form-control">
                            </div>
                            <div class="form-group" style="margin-top: 30px;">
                                <label for="disc_prof" style="color: rgb(87, 87, 87)">Professor:</label><br>
                                <select class="form-control" name="disc_prof" id="disc_prof">
                                    @foreach($disciplinas as $disciplina)
                                        <option value="{{ $disciplina->id_disciplina }}">{{ $disciplina->nome }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <center><input type="submit" name="submit" class="btn btn-success btn-md" style="margin-top: 10px;" value="Cadastrar"></center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
    
