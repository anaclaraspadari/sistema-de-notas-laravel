<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sistema de Notas - Boletim</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/aa4537a345.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container" style="margin-top: 40px">
        <h3>Boletim do Aluno {{ $aluno->nome }}</h3>
        <br/>
        <table class="table">
            <thead>
                <tr>
                    {{-- <th scope="col">Bimestre</th> --}}
                    <th scope="col">Cód. Disciplina</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Nota</th>
                    <th scope="col">Frequencia</th>
                    <th scope="col">Situação Final</th>
                </tr>
                @foreach($boletins as $boletim)
                    <tr>
                        <td>{{ $boletim->cod_disciplina }}</td>
                        <td>{{ $boletim->nome }}</td>
                        <td>{{ $boletim->nota }}</td>
                        <td>{{ $boletim->frequencia }}</a></td>
                        <td>{{ $boletim->situacao_final }}</a></td>
                        {{-- <td><center><a class="btn btn-primary btn-sm" href="{{ url('/editar-boletim') }}" role="button"><i class="fa-regular fa-pen-to-square"></i>&nbsp;Editar</a></center></td>
                        <td><center><a class="btn btn-danger btn-sm" href="{{ url('/excluir-boletim') }}" role="button"><i class="fa-solid fa-trash-can"></i>&nbsp;Excluir</a></center></td> --}}
                    </tr>
                @endforeach
            </thead>
        </table>
        <center>
            <a class="btn btn-secondary btn-sm" href="{{ url('/alunos') }}" role="button"><i class="fa-solid fa-arrow-left"></i>&nbsp;Voltar</a>
            <a class="btn btn-secondary btn-sm" href="{{ url('/inserir-boletim', $aluno->id_aluno) }}" role="button"><i class="fa-regular fa-pen-to-square"></i>&nbsp;Inserir</a>
        </center>
    </div>
</body>
</html>

