<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listagem de Professores</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/aa4537a345.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container" style="margin-top: 40px">
        <h3>Lista de Professores</h3>
        <br/>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Nome</th>
                    <th scope="col">E-mail</th>
                    <th scope="col">Disciplina</th>
                    <th scope="col">Alunos</th>
                </tr>
                @foreach($professores as $professor)
                    <tr>
                        <td>{{ $professor->nome }}</td>
                        <td>{{ $professor->email }}</td>
                        <td>{{ $professor->disciplina }}</td>
                        <td><a href="{{ url('/alunos-professores', $professor->id_professor) }}">Todos os alunos</a></td>
                        {{-- <td><center><a class="btn btn-primary btn-sm" href="{{ url('/editar-professores') }}" role="button"><i class="fa-regular fa-pen-to-square"></i>&nbsp;Editar</a></center></td>
                        <td><center><a class="btn btn-danger btn-sm" href="{{ url('/excluir-professores') }}" role="button"><i class="fa-solid fa-trash-can"></i>&nbsp;Excluir</a></center></td> --}}
                    </tr>
                @endforeach
            </thead>
        </table>
        <center>
            <a class="btn btn-secondary btn-sm" href="{{ url('/') }}" role="button"><i class="fa-solid fa-arrow-left"></i>&nbsp;Voltar</a>
            <a class="btn btn-secondary btn-sm" href="{{ url('/inserir-disciplinas') }}" role="button"><i class="fa-regular fa-pen-to-square"></i>&nbsp;Inserir</a>
        </center>
    </div>
</body>
</html>