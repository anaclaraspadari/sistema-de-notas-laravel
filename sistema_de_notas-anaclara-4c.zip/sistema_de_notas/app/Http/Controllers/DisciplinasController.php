<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\DisciplinasModel;
use App\Models\ProfessoresModel;
use Illuminate\Support\Facades\Log;

class DisciplinasController extends Controller
{
    public function getDisciplinas(){
        //return view('disciplinas');
        // $disciplinas = DisciplinasModel::all();
        $disciplinas= DisciplinasModel::select(
            'disciplinas.cod_disciplina as disciplina',
            'disciplinas.nome',
            'disciplinas.carga_horaria',
            'professores.nome as professor')
            ->join('professores','professores.id_professor','=','disciplinas.professor')
            ->get();
        // error_log("Buscando disciplinas: ");
        $data = array();
        $data['disciplinas'] = $disciplinas;
        return view('disciplinas', $data);
    }
    public function getInsertDisciplinasView(){
        return view('inserir-disciplinas');
    }

    public function insertDisciplinas(Request $request){
        $randomNumber = random_int(100000, 999999);

        $disciplinasModel=new DisciplinasModel();
        $disciplinasModel->cod_disciplina=$randomNumber;
        $disciplinasModel->nome=$request->nome_disc;
        $disciplinasModel->carga_horaria=$request->carga_horaria_disc;
        // error_log("Buscando disciplinas: ".$request->disc_prof);
        $disciplinasModel->save();
        return redirect('/disciplinas');
    }
}
