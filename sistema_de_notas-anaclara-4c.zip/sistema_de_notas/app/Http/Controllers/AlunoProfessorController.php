<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\DisciplinasModel;
use App\Models\AlunosModel;
use App\Models\ProfessoresModel;
use App\Models\BoletimModel;
use Illuminate\Support\Facades\Log;

class AlunoProfessorController extends Controller
{
    public function getAlunosByProfessor($id){
        $alunos=AlunosModel::select(
            'professores.id_professor',
            'professores.nome',
            'alunos.id_aluno', 
            'alunos.nome as nome_aluno',
            'alunos.email as email_aluno',
            'alunos.matricula')
            ->join('boletim','boletim.aluno','=','alunos.id_aluno')
            ->join('disciplinas','disciplinas.id_disciplina','=','boletim.disciplina')
            ->join('professores','professores.disciplina','=','disciplinas.id_disciplina')
            ->where('professores.id_professor','=',$id)
            ->get();
        $data=array();
        $data['alunos']=$alunos;
        $professoresModel=ProfessoresModel::select( 'professores.id_professor as id_professor', 'professores.nome as nome')->where('professores.id_professor', $id)->first();
        // error_log("Buscando id professor: ".$professoresModel->id_professor);
        $data['professor']=$professoresModel;
        return view('alunos-professores', $data);
    }
}
