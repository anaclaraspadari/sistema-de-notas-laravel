<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\AlunosModel;
use Illuminate\Support\Facades\Log;

class HomeController extends Controller
{
    public function home(){
        return view('home');
    }
}
