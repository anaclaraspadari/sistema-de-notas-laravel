<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\DisciplinasModel;
use App\Models\ProfessoresModel;
use Illuminate\Support\Facades\Log;

class ProfessoresController extends Controller
{
    public function getProfessores(){
        // $professores=DB::select('select nome, email from professores');
        // return view('professores');
        // $professores = DB::table('professores')->get();
        $professores = ProfessoresModel::select(
            'professores.id_professor',
            'disciplinas.nome as disciplina',
            'professores.nome',
            'professores.email')
            ->join('disciplinas','professores.disciplina','=','disciplinas.id_disciplina')
            ->get();
        //error_log("Buscando professores: ");
        $data = array();
        $data['professores'] = $professores;
        return view('professores', $data);
    }
    public function getInsertProfessoresView(){
        $disciplinas=DisciplinasModel::all();
        $data=array();
        $data['disciplinas']=$disciplinas;
        return view('inserir-professores', $data);
    }
    public function insertProfessores(Request $request){
        $professoresModel=new ProfessoresModel();
        $professoresModel->nome=$request->nome_prof;
        $professoresModel->email=$request->email_prof;
        $professoresModel->disciplina=$request->disc_prof;
        $professoresModel->save();
        return redirect('/professores');
    }
}
