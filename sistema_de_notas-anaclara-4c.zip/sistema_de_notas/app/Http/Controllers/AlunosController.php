<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\AlunosModel;
use Illuminate\Support\Facades\Log;

class AlunosController extends Controller
{
    public function getAlunos(){
        //return view('alunos');
        $alunos = AlunosModel::all();
        error_log("Buscando alunos: ");
        $data = array();
        $data['alunos'] = $alunos;
        return view('alunos', $data);
    }

    public function getInsertAlunosView(){
        return view('inserir-alunos');
    }

    public function insertAlunos(Request $request){
        $randomNumber = random_int(10000000, 99999999);

        $alunosModel=new AlunosModel();
        $alunosModel->nome=$request->nome_aluno;
        $alunosModel->email=$request->email_aluno;
        $alunosModel->matricula=$randomNumber;
        $alunosModel->save();
        return redirect('/alunos');
    }
}
