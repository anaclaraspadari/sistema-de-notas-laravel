<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\DisciplinasModel;
use App\Models\AlunosModel;
use App\Models\BoletimModel;
use Illuminate\Support\Facades\Log;

class BoletimController extends Controller
{
    public function getBoletimByAluno($id){
        $boletins=BoletimModel::select(
            'disciplinas.cod_disciplina as cod_disciplina',
            'disciplinas.nome as nome',
            'boletim.frequencia',
            'boletim.nota',
            'boletim.situacao_final',
            'alunos.id_aluno', 
            'alunos.nome as nome_aluno')
                ->join('disciplinas','disciplinas.id_disciplina','=','boletim.disciplina')
                ->join('alunos','alunos.id_aluno','=','boletim.aluno')
                ->where('alunos.id_aluno','=',$id)
                ->get();
        $data=array();
        $data['boletins']=$boletins;
        $alunosModel=new AlunosModel();
        $data['aluno']=$alunosModel->getAlunoById($id);
        return view('boletim',$data);
    }

    public function getInsertBoletimView($id){
        $alunosModel=new AlunosModel();
        $data['aluno']=$alunosModel->getAlunoById($id);
        $disciplinas=DisciplinasModel::all();
        $data['disciplinas']=$disciplinas;
        return view('inserir-boletim',$data);
    }

    public function insertBoletim(Request $request, $id){
        $alunosModel=AlunosModel::select('alunos.id_aluno as id_aluno')->where('id_aluno',$id)->first();
        $boletimModel=new BoletimModel();
        $boletimModel->aluno=$alunosModel->id_aluno;
        $boletimModel->disciplina=$request->disc_boletim;
        $boletimModel->frequencia=$request->freq_boletim;
        $boletimModel->nota=$request->nota_boletim;
        if($boletimModel->frequencia<7 && $boletimModel->nota<7){
            $boletimModel->situacao_final='Reprovado';
        }else if($boletimModel->frequencia<7 && $boletimModel->nota>=7){
            $boletimModel->situacao_final='Reprovado';
        }else{
            $boletimModel->situacao_final='Aprovado';
        }
        $boletimModel->save();
        return redirect('/boletim/'.$id);
    }
}
