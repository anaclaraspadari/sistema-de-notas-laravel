<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DisciplinasModel extends Model
{
    use HasFactory;

    protected $primaryKey='id_disciplina';
    protected $filliable=[
        'cod_disciplina',
        'nome',
        'carga_horaria'
    ];
    protected $table='disciplinas';
    public $timestamps=false;

    public function disciplinas(){
        $disciplinas=DisciplinasModel::join('professores','professores.id_professor','=','disciplinas.professor');
        $disciplinas->select('disciplinas.cod_disciplina','disciplinas.nome as nome','disciplinas.professor as professor');
        return $disciplinas->get();
    }
}
