<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AlunosModel extends Model
{
    use HasFactory;
    
    protected $primaryKey='id_aluno';
    protected $filliable=[
        'nome',
        'email',
        'matricula'
    ];
    protected $table='alunos';
    public $timestamps=false;

    public function getAlunoById($id_aluno){
        $aluno=AlunosModel::where('id_aluno','=',$id_aluno);
        return $aluno->first();
    }
    public function getIdFromAluno($id_aluno){
        $aluno=AlunosModel::where('id_aluno','=',$id_aluno);
        return $aluno->first($id_aluno);
    }
}
