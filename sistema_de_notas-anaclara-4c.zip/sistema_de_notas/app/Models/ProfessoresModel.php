<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProfessoresModel extends Model
{
    use HasFactory;

    public $incrementing = false;

    protected $primaryKey='id_professor';
    protected $filliable=[
        'nome',
        'email',
        'disciplina'
    ];
    protected $table='professores';
    public $timestamps=false;
    
    public function getProfessorById($id_prof){
        $professor=ProfessoresModel::where('id_professor','=',$id_prof);
        return $professor->first();
    }
}
