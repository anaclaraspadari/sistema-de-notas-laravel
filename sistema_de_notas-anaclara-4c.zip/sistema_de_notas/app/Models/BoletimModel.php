<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BoletimModel extends Model
{
    use HasFactory;
    protected $filliable=[
        'id',
        'aluno',
        'disciplina',
        'frequencia',
        'nota',
        'situacao_final'
    ];
    protected $table='boletim';
    public $timestamps=false;

    public function boletim($id){
        $boletim=BoletinsModel::join('disciplinas','disciplinas.id_disciplina','=','boletim.disciplina');
        $boletim->join('alunos','alunos.id_aluno','=','boletim.aluno');
        $boletim->select('disciplinas.id_disciplina','disciplinas.nome','boletim.frequencia','boletim.nota','boletim.situacao_final');
        $boletim->where('id_aluno','=',$id)->first()->id_aluno;
        return $boletim->get();
    }
    
}
