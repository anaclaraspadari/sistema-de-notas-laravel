<strong><p>Conexão com banco: </p></strong>
<?php
    try {
        \DB::connection()->getPDO();
        echo \DB::connection()->getDatabaseName();
    } catch (\Exception $e) {
        print_r($e);
    }
?><?php /**PATH C:\Users\Pichau\Documents\Quarto-Ano-2022\DSI\Laravel\sistema_de_notas\resources\views/teste.blade.php ENDPATH**/ ?>