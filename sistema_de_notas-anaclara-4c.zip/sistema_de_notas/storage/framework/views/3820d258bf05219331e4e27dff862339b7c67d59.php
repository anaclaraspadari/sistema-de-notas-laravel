<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Notas - Home</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/aa4537a345.js" crossorigin="anonymous"></script>
    <style>
        .navbar-custom{
            min-height: 40px;
            padding-right: 20px;
            padding-left: 20px;
            background-color: #fafafa;
            background-image: -moz-linear-gradient(top,#fff,#f2f2f2);
            background-image: -webkit-gradient(linear,0 0,0 100%,from(#fff),to(#f2f2f2));
            background-image: -webkit-linear-gradient(top,#fff,#f2f2f2);
            background-image: -o-linear-gradient(top,#fff,#f2f2f2);
            background-image: linear-gradient(to bottom,#a09696,#111);
            background-repeat: repeat-x;
            border: 1px solid #d4d4d4;
            -webkit-border-radius: 4px;
            -moz-border-radius: 4px;
            border-radius: 4px;
            filter: progid:dximagetransform.microsoft.gradient(startColorstr='#ffffffff',endColorstr='#fff2f2f2',GradientType=0);
            *zoom: 1;
            -webkit-box-shadow: 0 1px 4px rgba(0,0,0,0.065);
            -moz-box-shadow: 0 1px 4px rgba(0,0,0,0.065);
            box-shadow: 0 1px 4px rgba(0,0,0,0.065);
        }
        .stretched-link::after {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: 1;
            pointer-events: auto;
            content: "";
            background-color: rgba(0,0,0,0);
        }
        .card:hover {
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <div class="container-fluid justify-content-center">
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container justify-content-center">
            <ul class="nav navbar-nav flex-fill justify-content-around"> 
                    <li class="nav-item">
                        <a class="nav-link text-light" href="#"></a>
                    </li>
                    <li class="nav-item">
                        <a class="navbar-brand text-light" href="#">Sistema de Notas</a></li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="#"></a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
    <div id="menu">
        <div class="container">
            <center><h1 style="margin-top: 70px">Bem vindo(a) ao sistema de notas</h1></center>
            <div id="menu-row" class="row" style="margin-top: 100px">
                <div class="card" style="width: 20rem; margin-top: 30px; display: inline-block">                       
                    <div class="card-body">
                        <center><i class="fa-solid fa-person-chalkboard fa-4x"></i></center>
                        <center><h5 class="card-title" style="margin-top: 30px;">Professores</h5></center>
                        <center><p class="card-text">Visualize todos os professores.</p></center>
                        <a href="<?php echo e(url('/professores')); ?>" class="stretched-link"></a>
                    </div>
                </div>
                <div class="card" style="width: 20rem; margin-top: 30px; margin-left: 70px; display: inline-block">                       
                    <div class="card-body">
                        <center><i class="fa-solid fa-people-line fa-4x"></i></center>
                        <center><h5 class="card-title" style="margin-top: 30px;">Alunos</h5></center>
                        <center><p class="card-text">Visualize todos os alunos.</p></center>
                        <a href="<?php echo e(url('/alunos')); ?>" class="stretched-link"></a>
                    </div>
                </div>
                <div class="card" style="width: 20rem; margin-top: 30px; margin-left: 70px; display: inline-block">                       
                    <div class="card-body">
                        <center><i class="fa-solid fa-book fa-4x"></i></center>
                        <center><h5 class="card-title" style="margin-top: 30px;">Disciplinas</h5></center>
                        <center><p class="card-text">Visualize todas as disciplinas.</p></center>
                        <a href="<?php echo e(url('/disciplinas')); ?>" class="stretched-link"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php /**PATH C:\Users\Pichau\Documents\Quarto-Ano-2022\DSI\Laravel\sistema_de_notas\resources\views/home.blade.php ENDPATH**/ ?>