<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Notas - Inserção de Notas</title>
</head>
<body>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/aa4537a345.js" crossorigin="anonymous"></script>

    <div class="container" style="margin-top: 50px">
        <center><h1 style="color: rgb(87, 87, 87)">Sistema de Notas</h1></center>
    </div>
    <div class="container" style="margin-top: 20px">
        <center><h3 style="color: rgb(87, 87, 87)">Cadastro de notas do aluno <?php echo e($aluno ->nome); ?></h3></center>
    </div>
    <div id="cadastro">
        <div class="container">
            <div id="cadastro-row" class="row justify-content-center align-items-center">
                <div id="cadastro-column" class="col-md-6">
                    <div id="cadastro-box" class="col-md-12">
                        <form id="cadastro-form" class="form" action="<?php echo e(url('/boletim-inserido', $aluno->id_aluno)); ?>" method="get">
                            <div class="form-group" style="margin-top: 30px;">
                                <label for="disc_boletim" style="color: rgb(87, 87, 87)"><b>Disciplina:</b></label><br>
                                <select class="form-control" name="disc_boletim" id="disc_boletim">
                                    <?php $__currentLoopData = $disciplinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disciplina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($disciplina->id_disciplina); ?>" ><?php echo e($disciplina->nome); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group" style="margin-top: 30px;">
                                <label for="freq_boletim" style="color: rgb(87, 87, 87)"><b>Frequência:</b></label><br>
                                <input type="text" name="freq_boletim" id="freq_boletim" class="form-control"/>
                            </div>
                            <div class="form-group" style="margin-top: 30px;">
                                <label for="nota_boletim" style="color: rgb(87, 87, 87)"><b>Nota:</b></label><br>
                                <input type="text" name="nota_boletim" id="nota_boletim" class="form-control"/>
                            </div>
                            <div class="form-group">
                                <center><input type="submit" name="submit" class="btn btn-secondary btn-md" style="margin-top: 10px;" value="Cadastrar"></center>
                                <center><a class="btn btn-secondary btn-sm" href="<?php echo e(url('/boletim', $aluno->id_aluno)); ?>" role="button" style="margin-top: 30px"><i class="fa-solid fa-arrow-left"></i>&nbsp;Voltar</a></center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
    
<?php /**PATH C:\Users\Pichau\Documents\Quarto-Ano-2022\DSI\Laravel\sistema_de_notas\resources\views/inserir-boletim.blade.php ENDPATH**/ ?>