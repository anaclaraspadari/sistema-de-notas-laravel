<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Notas - Disciplinas</title>
</head>
<body>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <div class="container" style="margin-top: 50px">
        <center><h1 style="color: green">Sistema de Notas</h1></center>
    </div>
    <div class="container" style="margin-top: 20px">
        <center><h3 style="color: green">Cadastro de Notas</h3></center>
    </div>
    <div id="cadastro-disc">
        <div class="container">
            <div id="cadastro-disc-row" class="row justify-content-center align-items-center">
                <div id="cadastro-disc-column" class="col-md-6">
                    <div id="cadastro-disc-box" class="col-md-12">
                        <form id="cadastro-disc-form" class="form" action="<?php echo e(url('/disciplinas-inseridas')); ?>" method="get">
                            <div class="form-group" style="margin-top: 30px;">
                                <label for="nome_disc" style="color: green">Nome da Disciplina:</label><br>
                                <input type="text" name="nome_disc" id="nome_disc" class="form-control">
                            </div>
                            <div class="form-group" style="margin-top: 30px;">
                                <label for="carga_horaria_disc" style="color: green">Carga Horária:</label><br>
                                <input type="text" name="carga_horaria_disc" id="carga_horaria_disc" class="form-control">
                            </div>
                            <div class="form-group" style="margin-top: 30px;">
                                <label for="disc_prof" style="color: green">Professor:</label><br>
                                <select class="form-control" name="disc_prof" id="disc_prof">
                                    <?php $__currentLoopData = $professores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($professor->id_professor); ?>"><?php echo e($professor->nome); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <center><input type="submit" name="submit" class="btn btn-success btn-md" style="margin-top: 10px;" value="Cadastrar"></center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
    
<?php /**PATH C:\Users\Pichau\Documents\Quarto-Ano-2022\DSI\Laravel\sistema_de_notas\resources\views/inserir-disciplinas.blade.php ENDPATH**/ ?>