<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listagem de Disciplinas</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/aa4537a345.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container" style="margin-top: 40px">
        <h3>Lista de Disciplinas</h3>
        <br/>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Código</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Carga Horária</th>
                    <th scope="col">Professor</th>
                </tr>
                <?php $__currentLoopData = $disciplinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disciplina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($disciplina->disciplina); ?></td>
                        <td><?php echo e($disciplina->nome); ?></td>
                        <td><?php echo e($disciplina->carga_horaria); ?></td>
                        <td><?php echo e($disciplina->professor); ?></td>
                        <td><center><a class="btn btn-primary btn-sm" href="<?php echo e(url('/editar-disciplinas')); ?>" role="button"><i class="fa-regular fa-pen-to-square"></i>&nbsp;Editar</a></center></td>
                        <td><center><a class="btn btn-danger btn-sm" href="<?php echo e(url('/excluir-disciplinas')); ?>" role="button"><i class="fa-solid fa-trash-can"></i>&nbsp;Excluir</a></center></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </thead>
        </table>
        <center>
            <a class="btn btn-secondary btn-sm" href="<?php echo e(url('/')); ?>" role="button"><i class="fa-solid fa-arrow-left"></i>&nbsp;Voltar</a>
            <a class="btn btn-secondary btn-sm" href="<?php echo e(url('/inserir-disciplinas')); ?>" role="button"><i class="fa-regular fa-pen-to-square"></i>&nbsp;Inserir</a>
        </center>
    </div>
</body>
</html><?php /**PATH C:\Users\Pichau\Documents\Quarto-Ano-2022\DSI\Laravel\sistema_de_notas\resources\views/disciplinas.blade.php ENDPATH**/ ?>