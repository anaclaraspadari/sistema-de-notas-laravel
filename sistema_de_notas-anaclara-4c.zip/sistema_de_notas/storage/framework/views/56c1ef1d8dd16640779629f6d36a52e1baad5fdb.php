<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sistema de Notas - Boletim</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/aa4537a345.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container" style="margin-top: 40px">
        <h3>Boletim do Aluno <?php echo e($aluno->nome); ?></h3>
        <br/>
        <table class="table">
            <thead>
                <tr>
                    
                    <th scope="col">Cód. Disciplina</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Nota</th>
                    <th scope="col">Frequencia</th>
                    <th scope="col">Situação Final</th>
                </tr>
                <?php $__currentLoopData = $boletins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boletim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($boletim->cod_disciplina); ?></td>
                        <td><?php echo e($boletim->nome); ?></td>
                        <td><?php echo e($boletim->nota); ?></td>
                        <td><?php echo e($boletim->frequencia); ?></a></td>
                        <td><?php echo e($boletim->situacao_final); ?></a></td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </thead>
        </table>
        <center>
            <a class="btn btn-secondary btn-sm" href="<?php echo e(url('/alunos')); ?>" role="button"><i class="fa-solid fa-arrow-left"></i>&nbsp;Voltar</a>
            <a class="btn btn-secondary btn-sm" href="<?php echo e(url('/inserir-boletim', $aluno->id_aluno)); ?>" role="button"><i class="fa-regular fa-pen-to-square"></i>&nbsp;Inserir</a>
        </center>
    </div>
</body>
</html>

<?php /**PATH C:\Users\Pichau\Documents\Quarto-Ano-2022\DSI\Laravel\sistema_de_notas\resources\views/boletim.blade.php ENDPATH**/ ?>