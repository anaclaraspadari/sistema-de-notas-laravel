<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listagem de Alunos</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/aa4537a345.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container" style="margin-top: 40px">
        <h3>Lista de Alunos</h3>
        <br/>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Nome</th>
                    <th scope="col">E-mail</th>
                    <th scope="col">Matrícula</th>
                    <th scope="col">Boletim</th>
                </tr>
                <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($aluno->nome); ?></td>
                        <td><?php echo e($aluno->email); ?></td>
                        <td><?php echo e($aluno->matricula); ?></a></td>
                        <td><a href="<?php echo e(url('/boletim', $aluno->id_aluno)); ?>">Ver mais</a></td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </thead>
        </table>
        <center>
            <a class="btn btn-secondary btn-sm" href="<?php echo e(url('/')); ?>" role="button"><i class="fa-solid fa-arrow-left"></i>&nbsp;Voltar</a>
            <a class="btn btn-secondary btn-sm" href="<?php echo e(url('/inserir-alunos')); ?>" role="button"><i class="fa-regular fa-pen-to-square"></i>&nbsp;Inserir</a>
        </center>
    </div>
</body>
</html>

<?php /**PATH C:\Users\Pichau\Documents\Quarto-Ano-2022\DSI\Laravel\sistema_de_notas\resources\views/alunos.blade.php ENDPATH**/ ?>