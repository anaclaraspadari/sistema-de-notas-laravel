<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/professores', function () {
//     return view('professores', [App\Http\Controllers\ProfessoresController::class, 'professores']);
// });

Route::get('/', [App\Http\Controllers\HomeController::class, 'home']);
Route::get('/professores', [App\Http\Controllers\ProfessoresController::class, 'getProfessores']);
Route::get('/alunos', [App\Http\Controllers\AlunosController::class, 'getAlunos']);
Route::get('/disciplinas', [App\Http\Controllers\DisciplinasController::class, 'getDisciplinas']);
Route::get('/inserir-alunos', [App\Http\Controllers\AlunosController::class, 'getInsertAlunosView']);
Route::get('/alunos-inseridos', [App\Http\Controllers\AlunosController::class, 'InsertAlunos']);
Route::get('/inserir-professores', [App\Http\Controllers\ProfessoresController::class, 'getInsertProfessoresView']);
Route::get('/professores-inseridos', [App\Http\Controllers\ProfessoresController::class, 'insertProfessores']);
Route::get('/inserir-disciplinas', [App\Http\Controllers\DisciplinasController::class, 'getInsertDisciplinasView']);
Route::get('/disciplinas-inseridas', [App\Http\Controllers\DisciplinasController::class, 'insertDisciplinas']);
Route::get('/boletim/{id}', [App\Http\Controllers\BoletimController::class, 'getBoletimByAluno']);
Route::get('/inserir-boletim/{id}', [App\Http\Controllers\BoletimController::class, 'getInsertBoletimView']);
Route::get('/boletim-inserido/{id}', [App\Http\Controllers\BoletimController::class, 'insertBoletim']);
Route::get('/alunos-professores/{id}', [App\Http\Controllers\AlunoProfessorController::class, 'getAlunosByProfessor']);