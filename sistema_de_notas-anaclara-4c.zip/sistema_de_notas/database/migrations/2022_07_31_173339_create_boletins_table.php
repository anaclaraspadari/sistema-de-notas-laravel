<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('boletins', function (Blueprint $table) {
            $table->id();
            $table->integer('aluno');
            $table->foreign('aluno')->references('id')->on('alunos');
            $table->integer('disciplina');
            $table->foreign('disciplina')->references('id')->on('disciplinas');
            $table->integer('frequencia');
            $table->decimal('nota',5,2);
            $table->text('situacao_final');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('boletins');
    }
};
