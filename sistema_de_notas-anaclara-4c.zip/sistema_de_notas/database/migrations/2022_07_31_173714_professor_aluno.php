<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('professor_aluno', function (Blueprint $table){
            $table->integer('aluno');
            $table->foreign('aluno')->references('id')->on('alunos');
            $table->integer('professor');
            $table->foreign('professor')->references('id')->on('professores');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('professor_aluno');
    }
};
